import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

import chroma from '@chromajs/vite-plugin-chroma';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    chroma(),
    react()
  ],
})
