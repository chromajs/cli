import { defineConfig } from "vite";
import chroma from "@chromajs/vite-plugin-chroma";

export default defineConfig({
    plugins: [
        chroma(),
    ],
});