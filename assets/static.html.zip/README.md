# Chroma (Static)

A start project for Chroma built with static HTML and a compiler.

# Getting Started

Edit ./src/index.html inside of the "chroma" tags to edit the Markdown.

# Compile

```bash
npx chroma-html-compiler -s ./src -o ./out
```

# Run

Open the compiled HTML file in your browser

# Documentation

https://chromajs.github.io/
